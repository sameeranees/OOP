#pragma once

using namespace std;

struct Person
//following variables and functions can be used anywhere else in the other files as long as it is included
{
    string Name;// name of guest
    string CNIC;//cnic of guest
    string DOB;//date of birth of guest
};
