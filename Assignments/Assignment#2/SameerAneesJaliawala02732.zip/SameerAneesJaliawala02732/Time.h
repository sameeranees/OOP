#pragma once

class Time
{
private:
    //time will have seconds, minutes, hours
    int seconds;
    int minutes;
    int hours;
public:
    Show();
};
